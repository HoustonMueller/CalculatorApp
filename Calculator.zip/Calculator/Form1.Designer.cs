﻿namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.signChangeBtn = new System.Windows.Forms.Button();
            this.oneBtn = new System.Windows.Forms.Button();
            this.fourBtn = new System.Windows.Forms.Button();
            this.sevenBtn = new System.Windows.Forms.Button();
            this.clearEntryBtn = new System.Windows.Forms.Button();
            this.sqrtBtn = new System.Windows.Forms.Button();
            this.outputBox = new System.Windows.Forms.TextBox();
            this.squareBtn = new System.Windows.Forms.Button();
            this.clearBtn = new System.Windows.Forms.Button();
            this.eightBtn = new System.Windows.Forms.Button();
            this.fiveBtn = new System.Windows.Forms.Button();
            this.twoBtn = new System.Windows.Forms.Button();
            this.zeroBtn = new System.Windows.Forms.Button();
            this.powerBtn = new System.Windows.Forms.Button();
            this.deleteBtn = new System.Windows.Forms.Button();
            this.nineBtn = new System.Windows.Forms.Button();
            this.sixBtn = new System.Windows.Forms.Button();
            this.oneOverBtn = new System.Windows.Forms.Button();
            this.divideBtn = new System.Windows.Forms.Button();
            this.multiplyBtn = new System.Windows.Forms.Button();
            this.minusBtn = new System.Windows.Forms.Button();
            this.plusBtn = new System.Windows.Forms.Button();
            this.equalBtn = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.threeBtn = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.decimalBtn = new System.Windows.Forms.Button();
            this.historyBox0 = new System.Windows.Forms.TextBox();
            this.historyBox1 = new System.Windows.Forms.TextBox();
            this.historyBox2 = new System.Windows.Forms.TextBox();
            this.historyBox3 = new System.Windows.Forms.TextBox();
            this.historyBox4 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // signChangeBtn
            // 
            this.signChangeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signChangeBtn.Location = new System.Drawing.Point(12, 561);
            this.signChangeBtn.Name = "signChangeBtn";
            this.signChangeBtn.Size = new System.Drawing.Size(93, 75);
            this.signChangeBtn.TabIndex = 1;
            this.signChangeBtn.Text = "+/-";
            this.signChangeBtn.UseVisualStyleBackColor = true;
            this.signChangeBtn.Click += new System.EventHandler(this.signChangeBtn_Click);
            // 
            // oneBtn
            // 
            this.oneBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oneBtn.Location = new System.Drawing.Point(12, 480);
            this.oneBtn.Name = "oneBtn";
            this.oneBtn.Size = new System.Drawing.Size(93, 75);
            this.oneBtn.TabIndex = 2;
            this.oneBtn.Text = "1";
            this.oneBtn.UseVisualStyleBackColor = true;
            this.oneBtn.Click += new System.EventHandler(this.oneBtn_Click);
            // 
            // fourBtn
            // 
            this.fourBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fourBtn.Location = new System.Drawing.Point(12, 399);
            this.fourBtn.Name = "fourBtn";
            this.fourBtn.Size = new System.Drawing.Size(93, 75);
            this.fourBtn.TabIndex = 3;
            this.fourBtn.Text = "4";
            this.fourBtn.UseVisualStyleBackColor = true;
            this.fourBtn.Click += new System.EventHandler(this.fourBtn_Click);
            // 
            // sevenBtn
            // 
            this.sevenBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sevenBtn.Location = new System.Drawing.Point(12, 318);
            this.sevenBtn.Name = "sevenBtn";
            this.sevenBtn.Size = new System.Drawing.Size(93, 75);
            this.sevenBtn.TabIndex = 4;
            this.sevenBtn.Text = "7";
            this.sevenBtn.UseVisualStyleBackColor = true;
            this.sevenBtn.Click += new System.EventHandler(this.sevenBtn_Click);
            // 
            // clearEntryBtn
            // 
            this.clearEntryBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearEntryBtn.Location = new System.Drawing.Point(12, 237);
            this.clearEntryBtn.Name = "clearEntryBtn";
            this.clearEntryBtn.Size = new System.Drawing.Size(93, 75);
            this.clearEntryBtn.TabIndex = 5;
            this.clearEntryBtn.Text = "CE";
            this.clearEntryBtn.UseVisualStyleBackColor = true;
            this.clearEntryBtn.Click += new System.EventHandler(this.clearEntryBtn_Click);
            // 
            // sqrtBtn
            // 
            this.sqrtBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sqrtBtn.Location = new System.Drawing.Point(12, 156);
            this.sqrtBtn.Name = "sqrtBtn";
            this.sqrtBtn.Size = new System.Drawing.Size(93, 75);
            this.sqrtBtn.TabIndex = 6;
            this.sqrtBtn.Text = "Sqrt";
            this.sqrtBtn.UseVisualStyleBackColor = true;
            this.sqrtBtn.Click += new System.EventHandler(this.sqrtBtn_Click);
            // 
            // outputBox
            // 
            this.outputBox.BackColor = System.Drawing.SystemColors.Control;
            this.outputBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.outputBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outputBox.Location = new System.Drawing.Point(12, 12);
            this.outputBox.MaxLength = 12;
            this.outputBox.Multiline = true;
            this.outputBox.Name = "outputBox";
            this.outputBox.ReadOnly = true;
            this.outputBox.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.outputBox.Size = new System.Drawing.Size(448, 136);
            this.outputBox.TabIndex = 7;
            this.outputBox.Text = "0";
            this.outputBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.outputBox.TextChanged += new System.EventHandler(this.outputBox_TextChanged);
            // 
            // squareBtn
            // 
            this.squareBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.squareBtn.Location = new System.Drawing.Point(125, 156);
            this.squareBtn.Name = "squareBtn";
            this.squareBtn.Size = new System.Drawing.Size(93, 75);
            this.squareBtn.TabIndex = 13;
            this.squareBtn.Text = "X^2";
            this.squareBtn.UseVisualStyleBackColor = true;
            this.squareBtn.Click += new System.EventHandler(this.squareBtn_Click);
            // 
            // clearBtn
            // 
            this.clearBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearBtn.Location = new System.Drawing.Point(125, 237);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(93, 75);
            this.clearBtn.TabIndex = 12;
            this.clearBtn.Text = "C";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // eightBtn
            // 
            this.eightBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eightBtn.Location = new System.Drawing.Point(125, 318);
            this.eightBtn.Name = "eightBtn";
            this.eightBtn.Size = new System.Drawing.Size(93, 75);
            this.eightBtn.TabIndex = 11;
            this.eightBtn.Text = "8";
            this.eightBtn.UseVisualStyleBackColor = true;
            this.eightBtn.Click += new System.EventHandler(this.eightBtn_Click);
            // 
            // fiveBtn
            // 
            this.fiveBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fiveBtn.Location = new System.Drawing.Point(125, 399);
            this.fiveBtn.Name = "fiveBtn";
            this.fiveBtn.Size = new System.Drawing.Size(93, 75);
            this.fiveBtn.TabIndex = 10;
            this.fiveBtn.Text = "5";
            this.fiveBtn.UseVisualStyleBackColor = true;
            this.fiveBtn.Click += new System.EventHandler(this.fiveBtn_Click);
            // 
            // twoBtn
            // 
            this.twoBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.twoBtn.Location = new System.Drawing.Point(125, 480);
            this.twoBtn.Name = "twoBtn";
            this.twoBtn.Size = new System.Drawing.Size(93, 75);
            this.twoBtn.TabIndex = 9;
            this.twoBtn.Text = "2";
            this.twoBtn.UseVisualStyleBackColor = true;
            this.twoBtn.Click += new System.EventHandler(this.twoBtn_Click);
            // 
            // zeroBtn
            // 
            this.zeroBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zeroBtn.Location = new System.Drawing.Point(125, 561);
            this.zeroBtn.Name = "zeroBtn";
            this.zeroBtn.Size = new System.Drawing.Size(93, 75);
            this.zeroBtn.TabIndex = 8;
            this.zeroBtn.Text = "0";
            this.zeroBtn.UseVisualStyleBackColor = true;
            this.zeroBtn.Click += new System.EventHandler(this.zeroBtn_Click);
            // 
            // powerBtn
            // 
            this.powerBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.powerBtn.Location = new System.Drawing.Point(243, 156);
            this.powerBtn.Name = "powerBtn";
            this.powerBtn.Size = new System.Drawing.Size(93, 75);
            this.powerBtn.TabIndex = 19;
            this.powerBtn.Text = "X^Y";
            this.powerBtn.UseVisualStyleBackColor = true;
            this.powerBtn.Click += new System.EventHandler(this.powerBtn_Click);
            // 
            // deleteBtn
            // 
            this.deleteBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteBtn.Location = new System.Drawing.Point(243, 237);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(93, 75);
            this.deleteBtn.TabIndex = 18;
            this.deleteBtn.Text = "Delete";
            this.deleteBtn.UseVisualStyleBackColor = true;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // nineBtn
            // 
            this.nineBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nineBtn.Location = new System.Drawing.Point(243, 318);
            this.nineBtn.Name = "nineBtn";
            this.nineBtn.Size = new System.Drawing.Size(93, 75);
            this.nineBtn.TabIndex = 17;
            this.nineBtn.Text = "9";
            this.nineBtn.UseVisualStyleBackColor = true;
            this.nineBtn.Click += new System.EventHandler(this.nineBtn_Click);
            // 
            // sixBtn
            // 
            this.sixBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sixBtn.Location = new System.Drawing.Point(243, 399);
            this.sixBtn.Name = "sixBtn";
            this.sixBtn.Size = new System.Drawing.Size(93, 75);
            this.sixBtn.TabIndex = 16;
            this.sixBtn.Text = "6";
            this.sixBtn.UseVisualStyleBackColor = true;
            this.sixBtn.Click += new System.EventHandler(this.sixBtn_Click);
            // 
            // oneOverBtn
            // 
            this.oneOverBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oneOverBtn.Location = new System.Drawing.Point(368, 155);
            this.oneOverBtn.Name = "oneOverBtn";
            this.oneOverBtn.Size = new System.Drawing.Size(93, 75);
            this.oneOverBtn.TabIndex = 25;
            this.oneOverBtn.Text = "1/X";
            this.oneOverBtn.UseVisualStyleBackColor = true;
            this.oneOverBtn.Click += new System.EventHandler(this.oneOverBtn_Click);
            // 
            // divideBtn
            // 
            this.divideBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.divideBtn.Location = new System.Drawing.Point(368, 237);
            this.divideBtn.Name = "divideBtn";
            this.divideBtn.Size = new System.Drawing.Size(93, 75);
            this.divideBtn.TabIndex = 24;
            this.divideBtn.Text = "/";
            this.divideBtn.UseVisualStyleBackColor = true;
            this.divideBtn.Click += new System.EventHandler(this.divideBtn_Click);
            // 
            // multiplyBtn
            // 
            this.multiplyBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.multiplyBtn.Location = new System.Drawing.Point(368, 318);
            this.multiplyBtn.Name = "multiplyBtn";
            this.multiplyBtn.Size = new System.Drawing.Size(93, 75);
            this.multiplyBtn.TabIndex = 23;
            this.multiplyBtn.Text = "*";
            this.multiplyBtn.UseVisualStyleBackColor = true;
            this.multiplyBtn.Click += new System.EventHandler(this.multiplyBtn_Click);
            // 
            // minusBtn
            // 
            this.minusBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minusBtn.Location = new System.Drawing.Point(368, 399);
            this.minusBtn.Name = "minusBtn";
            this.minusBtn.Size = new System.Drawing.Size(93, 75);
            this.minusBtn.TabIndex = 22;
            this.minusBtn.Text = "-";
            this.minusBtn.UseVisualStyleBackColor = true;
            this.minusBtn.Click += new System.EventHandler(this.minusBtn_Click);
            // 
            // plusBtn
            // 
            this.plusBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plusBtn.Location = new System.Drawing.Point(368, 480);
            this.plusBtn.Name = "plusBtn";
            this.plusBtn.Size = new System.Drawing.Size(93, 75);
            this.plusBtn.TabIndex = 21;
            this.plusBtn.Text = "+";
            this.plusBtn.UseVisualStyleBackColor = true;
            this.plusBtn.Click += new System.EventHandler(this.plusBtn_Click);
            // 
            // equalBtn
            // 
            this.equalBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.equalBtn.Location = new System.Drawing.Point(368, 561);
            this.equalBtn.Name = "equalBtn";
            this.equalBtn.Size = new System.Drawing.Size(93, 75);
            this.equalBtn.TabIndex = 20;
            this.equalBtn.Text = " =";
            this.equalBtn.UseVisualStyleBackColor = true;
            this.equalBtn.Click += new System.EventHandler(this.equalBtn_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // threeBtn
            // 
            this.threeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.threeBtn.Location = new System.Drawing.Point(243, 480);
            this.threeBtn.Name = "threeBtn";
            this.threeBtn.Size = new System.Drawing.Size(93, 75);
            this.threeBtn.TabIndex = 26;
            this.threeBtn.Text = "3";
            this.threeBtn.UseVisualStyleBackColor = true;
            this.threeBtn.Click += new System.EventHandler(this.threeBtn_Click);
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.Control;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(497, 12);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(240, 28);
            this.textBox2.TabIndex = 28;
            this.textBox2.Text = "History";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // decimalBtn
            // 
            this.decimalBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.decimalBtn.Location = new System.Drawing.Point(243, 561);
            this.decimalBtn.Name = "decimalBtn";
            this.decimalBtn.Size = new System.Drawing.Size(93, 75);
            this.decimalBtn.TabIndex = 29;
            this.decimalBtn.Text = ".";
            this.decimalBtn.UseVisualStyleBackColor = true;
            this.decimalBtn.Click += new System.EventHandler(this.decimalBtn_Click);
            // 
            // historyBox0
            // 
            this.historyBox0.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.historyBox0.Location = new System.Drawing.Point(467, 204);
            this.historyBox0.Multiline = true;
            this.historyBox0.Name = "historyBox0";
            this.historyBox0.ReadOnly = true;
            this.historyBox0.Size = new System.Drawing.Size(270, 45);
            this.historyBox0.TabIndex = 30;
            this.historyBox0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.historyBox0.TextChanged += new System.EventHandler(this.historyBox0_TextChanged);
            // 
            // historyBox1
            // 
            this.historyBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.historyBox1.Location = new System.Drawing.Point(467, 286);
            this.historyBox1.Multiline = true;
            this.historyBox1.Name = "historyBox1";
            this.historyBox1.ReadOnly = true;
            this.historyBox1.Size = new System.Drawing.Size(270, 52);
            this.historyBox1.TabIndex = 31;
            this.historyBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.historyBox1.TextChanged += new System.EventHandler(this.historyBox1_TextChanged);
            // 
            // historyBox2
            // 
            this.historyBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.historyBox2.Location = new System.Drawing.Point(467, 367);
            this.historyBox2.Multiline = true;
            this.historyBox2.Name = "historyBox2";
            this.historyBox2.ReadOnly = true;
            this.historyBox2.Size = new System.Drawing.Size(270, 26);
            this.historyBox2.TabIndex = 32;
            this.historyBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.historyBox2.TextChanged += new System.EventHandler(this.historyBox2_TextChanged);
            // 
            // historyBox3
            // 
            this.historyBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.historyBox3.Location = new System.Drawing.Point(467, 448);
            this.historyBox3.Multiline = true;
            this.historyBox3.Name = "historyBox3";
            this.historyBox3.ReadOnly = true;
            this.historyBox3.Size = new System.Drawing.Size(270, 56);
            this.historyBox3.TabIndex = 33;
            this.historyBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.historyBox3.TextChanged += new System.EventHandler(this.historyBox3_TextChanged);
            // 
            // historyBox4
            // 
            this.historyBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.historyBox4.Location = new System.Drawing.Point(467, 529);
            this.historyBox4.Multiline = true;
            this.historyBox4.Name = "historyBox4";
            this.historyBox4.ReadOnly = true;
            this.historyBox4.Size = new System.Drawing.Size(270, 56);
            this.historyBox4.TabIndex = 34;
            this.historyBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.historyBox4.TextChanged += new System.EventHandler(this.historyBox4_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(749, 648);
            this.Controls.Add(this.historyBox4);
            this.Controls.Add(this.historyBox3);
            this.Controls.Add(this.historyBox2);
            this.Controls.Add(this.historyBox1);
            this.Controls.Add(this.historyBox0);
            this.Controls.Add(this.decimalBtn);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.threeBtn);
            this.Controls.Add(this.oneOverBtn);
            this.Controls.Add(this.divideBtn);
            this.Controls.Add(this.multiplyBtn);
            this.Controls.Add(this.minusBtn);
            this.Controls.Add(this.plusBtn);
            this.Controls.Add(this.equalBtn);
            this.Controls.Add(this.powerBtn);
            this.Controls.Add(this.deleteBtn);
            this.Controls.Add(this.nineBtn);
            this.Controls.Add(this.sixBtn);
            this.Controls.Add(this.squareBtn);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.eightBtn);
            this.Controls.Add(this.fiveBtn);
            this.Controls.Add(this.twoBtn);
            this.Controls.Add(this.zeroBtn);
            this.Controls.Add(this.outputBox);
            this.Controls.Add(this.sqrtBtn);
            this.Controls.Add(this.clearEntryBtn);
            this.Controls.Add(this.sevenBtn);
            this.Controls.Add(this.fourBtn);
            this.Controls.Add(this.oneBtn);
            this.Controls.Add(this.signChangeBtn);
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button signChangeBtn;
        private System.Windows.Forms.Button oneBtn;
        private System.Windows.Forms.Button fourBtn;
        private System.Windows.Forms.Button sevenBtn;
        private System.Windows.Forms.Button clearEntryBtn;
        private System.Windows.Forms.Button sqrtBtn;
        private System.Windows.Forms.TextBox outputBox;
        private System.Windows.Forms.Button squareBtn;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.Button eightBtn;
        private System.Windows.Forms.Button fiveBtn;
        private System.Windows.Forms.Button twoBtn;
        private System.Windows.Forms.Button zeroBtn;
        private System.Windows.Forms.Button powerBtn;
        private System.Windows.Forms.Button deleteBtn;
        private System.Windows.Forms.Button nineBtn;
        private System.Windows.Forms.Button sixBtn;
        private System.Windows.Forms.Button oneOverBtn;
        private System.Windows.Forms.Button divideBtn;
        private System.Windows.Forms.Button multiplyBtn;
        private System.Windows.Forms.Button minusBtn;
        private System.Windows.Forms.Button plusBtn;
        private System.Windows.Forms.Button equalBtn;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Button threeBtn;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button decimalBtn;
        private System.Windows.Forms.TextBox historyBox0;
        private System.Windows.Forms.TextBox historyBox1;
        private System.Windows.Forms.TextBox historyBox2;
        private System.Windows.Forms.TextBox historyBox3;
        private System.Windows.Forms.TextBox historyBox4;
    }
}

