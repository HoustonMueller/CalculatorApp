﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        #region private variables
        private double output;
        private string operand1 = "";
        private string operand1a = "";
        private string operand2 = "";
        private string operand2a;
        private string[] history = { "", "", "", "", "" };
        private int historyCount = 0;
        private Operation currentOperation = Operation.NoneSelected;
        #endregion
        #region public classes

        public enum Operation
        {
            NoneSelected = 0,
            SquareRoot = 1,
            Square = 2,
            Power = 3,
            Reciprocal = 4,

            Division = 5,
            Multiplication = 6,
            Subtraction = 7,
            Addition = 8
        }

        public Form1()
        {
            InitializeComponent();
            this.KeyPress += new KeyPressEventHandler(frmCalculator_KeyPress);
        }
        #endregion
        #region keyboard input
        void frmCalculator_KeyPress(object sender, KeyPressEventArgs e)
        { //keyboard inputs
            switch (e.KeyChar)
            {
                case '0':
                    zeroBtn_Click(sender, e);
                    break;
                case '1':
                    oneBtn_Click(sender, e);
                    break;
                case '2':
                    twoBtn_Click(sender, e);
                    break;
                case '3':
                    threeBtn_Click(sender, e);
                    break;
                case '4':
                    fourBtn_Click(sender, e);
                    break;
                case '5':
                    fiveBtn_Click(sender, e);
                    break;
                case '6':
                    sixBtn_Click(sender, e);
                    break;
                case '7':
                    sevenBtn_Click(sender, e);
                    break;
                case '8':
                    eightBtn_Click(sender, e);
                    break;
                case '9':
                    nineBtn_Click(sender, e);
                    break;
                case '+':
                    plusBtn_Click(sender, e);
                    break;
                case '-':
                    minusBtn_Click(sender, e);
                    break;
                case '*':
                    multiplyBtn_Click(sender, e);
                    break;
                case '/':
                    divideBtn_Click(sender, e);
                    break;
                case (char)8: // Backspace
                    deleteBtn_Click(sender, e);
                    break;
                case (char)27: // Escape
                    clearBtn_Click(sender, e);
                    break;
                case '=':
                    equalBtn_Click(sender, e);
                    break;
                case '.':
                    decimalBtn_Click(sender, e);
                    break;
                default:
                    e.Handled = true;
                    break;
            }
        }
        #endregion
        #region textboxes
        private void outputBox_TextChanged(object sender, EventArgs e)
        {

        }
        private void historyBox0_TextChanged(object sender, EventArgs e)
        {

        }

        private void historyBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void historyBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void historyBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void historyBox4_TextChanged(object sender, EventArgs e)
        {

        }
        #endregion
        #region Number clicks
        private void oneBtn_Click(object sender, EventArgs e)
        {
            if (currentOperation == Operation.NoneSelected && operand1.Length < 12)
            { 
                operand1 += "1";
                outputBox.Text = operand1;
            }
            if (currentOperation != Operation.NoneSelected && operand2.Length < 12)
            {
                outputBox.Text = "";
                operand2 += "1";
                outputBox.Text = operand2;
            }
        }

        private void twoBtn_Click(object sender, EventArgs e)
        {
            if (currentOperation == Operation.NoneSelected && operand1.Length < 12)
            {
                operand1 += "2";
                outputBox.Text = operand1;
            }
            if (currentOperation != Operation.NoneSelected && operand2.Length < 12)
            {
                outputBox.Text = "";
                operand2 += "2";
                outputBox.Text = operand2;
            }
        }
        private void threeBtn_Click(object sender, EventArgs e)
        {
            if (currentOperation == Operation.NoneSelected && operand1.Length < 12)
            {
                operand1 += "3";
                outputBox.Text = operand1;
            }
            if (currentOperation != Operation.NoneSelected && operand2.Length < 12)
            {
                outputBox.Text = "";
                operand2 += "3";
                outputBox.Text = operand2;
            }
        }
        private void fourBtn_Click(object sender, EventArgs e)
        {
            if (currentOperation == Operation.NoneSelected && operand1.Length < 12)
            {
                operand1 += "4";
                outputBox.Text = operand1;
            }
            if (currentOperation != Operation.NoneSelected && operand2.Length < 12)
            {
                outputBox.Text = "";
                operand2 += "4";
                outputBox.Text = operand2;
            }
        }

        private void fiveBtn_Click(object sender, EventArgs e)
        {
            if (currentOperation == Operation.NoneSelected && operand1.Length < 12)
            {
                operand1 += "5";
                outputBox.Text = operand1;
            }
            if (currentOperation != Operation.NoneSelected && operand2.Length < 12)
            {
                outputBox.Text = "";
                operand2 += "5";
                outputBox.Text = operand2;
            }
        }

        private void sixBtn_Click(object sender, EventArgs e)
        {
            if (currentOperation == Operation.NoneSelected && operand1.Length < 12)
            {
                operand1 += "6";
                outputBox.Text = operand1;
            }
            if (currentOperation != Operation.NoneSelected && operand2.Length < 12)
            {
                outputBox.Text = "";
                operand2 += "6";
                outputBox.Text = operand2;
            }
        }

        private void sevenBtn_Click(object sender, EventArgs e)
        {
            if (currentOperation == Operation.NoneSelected && operand1.Length < 12)
            {
                operand1 += "7";
                outputBox.Text = operand1;
            }
            if (currentOperation != Operation.NoneSelected && operand2.Length < 12)
            {
                outputBox.Text = "";
                operand2 += "7";
                outputBox.Text = operand2;
            }
        }

        private void eightBtn_Click(object sender, EventArgs e)
        {
            if (currentOperation == Operation.NoneSelected && operand1.Length < 12)
            {
                operand1 += "8";
                outputBox.Text = operand1;
            }
            if (currentOperation != Operation.NoneSelected && operand2.Length < 12)
            {
                outputBox.Text = "";
                operand2 += "8";
                outputBox.Text = operand2;
            }
        }

        private void nineBtn_Click(object sender, EventArgs e)
        {
            if (currentOperation == Operation.NoneSelected && operand1.Length < 12)
            {
                operand1 += "9";
                outputBox.Text = operand1;
            }
            if (currentOperation != Operation.NoneSelected && operand2.Length < 12)
            {
                outputBox.Text = "";
                operand2 += "9";
                outputBox.Text = operand2;
            }
        }

        private void zeroBtn_Click(object sender, EventArgs e)
        {
            if (outputBox.Text != "0")
            {
                if (currentOperation == Operation.NoneSelected && operand1.Length < 12)
                {

                    operand1 += "0";
                    outputBox.Text = operand1;

                }
                if (currentOperation != Operation.NoneSelected && operand2.Length < 12)
                {
                    outputBox.Text = "";
                    operand2 += "0";
                    outputBox.Text = operand2;
                }
            }
        }
        #endregion
        #region sign change/decimal functions
        private void decimalBtn_Click(object sender, EventArgs e)
        {
            if (currentOperation == Operation.NoneSelected && !operand1.Contains('.'))
            {
                operand1 += ".";
                outputBox.Text = operand1;
            }
            if (currentOperation != Operation.NoneSelected && !operand2.Contains('.'))
            {
                outputBox.Text = "";
                operand2 += ".";
                outputBox.Text = operand2;
            }
        }
        private void signChangeBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (currentOperation == Operation.NoneSelected && operand1[0] != '-' && outputBox.Text != "0")
                {
                    operand1 = "-" + operand1;
                    outputBox.Text = operand1;
                }
                else if (currentOperation == Operation.NoneSelected && operand1[0] == '-')
                {
                    operand1 = operand1.Substring(1);
                    outputBox.Text = operand1;
                }

                if (operand2 == "")
                {
                    operand2 += " ";
                }
                if (currentOperation != Operation.NoneSelected && operand2[0] != '-' && operand2 != " ")
                {
                    outputBox.Text = "";
                    operand2 = "-" + operand2;
                    outputBox.Text = operand2;
                }
                else if (currentOperation != Operation.NoneSelected && operand2[0] == '-')
                {
                    operand2 = operand2.Substring(1);
                    outputBox.Text = operand2;
                }
            }
            catch { }

        }
        #endregion
        #region operation functions
        private void plusBtn_Click(object sender, EventArgs e)
        {
            currentOperation = Operation.Addition;
        }
        private void minusBtn_Click(object sender, EventArgs e)
        {
            currentOperation = Operation.Subtraction;
        }
        private void multiplyBtn_Click(object sender, EventArgs e)
        {
            currentOperation = Operation.Multiplication;
        }
        private void divideBtn_Click(object sender, EventArgs e)
        {
            currentOperation = Operation.Division;
        }
        private void oneOverBtn_Click(object sender, EventArgs e)
        {//reciprical button calculates instantly without clicking equals,
         //so calculation and output is done on button click
            currentOperation = Operation.Reciprocal;
            output = 1 / Convert.ToDouble(operand1);
            output = Math.Round(output, 15);
            operand1a = operand1;
            operand1 = output.ToString();
            checkLength();
            addToHistory('_');
        }
        private void sqrtBtn_Click(object sender, EventArgs e)
        {//square root button calculates instantly without clicking equals,
         //so calculation and output is done on button click
            currentOperation = Operation.SquareRoot;
            output = Math.Sqrt(Convert.ToDouble(operand1));
            operand1a = operand1;
            operand1 = output.ToString();
            checkLength();
            addToHistory('_');
        }
        private void squareBtn_Click(object sender, EventArgs e)
        { //square button calculates instantly without clicking equals,
          //so calculation and output is done on button click
            currentOperation = Operation.Square;
            output = Convert.ToDouble(operand1) * Convert.ToDouble(operand1);
            operand1a = operand1;
            operand1 = output.ToString();
            checkLength();
            addToHistory('_');
        }
        private void powerBtn_Click(object sender, EventArgs e)
        {
            currentOperation = Operation.Power;
        }
        #endregion
        #region deletion functions
        private void deleteBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (currentOperation == Operation.NoneSelected)
                { //if operation hasn't been selected remove last number from string of operand1
                    operand1 = operand1.Substring(0, operand1.Length - 1);
                    if (operand1 == "") //if string is empty don't modify operand1; set textbox to "0"
                        outputBox.Text = "0";
                    else
                    {
                        outputBox.Text = operand1;
                    }

                }
                else if (operand2 != "")
                { //if currently entering operand2, remove last number from string of operand2
                    operand2 = operand2.Substring(0, operand2.Length - 1);
                    if (operand2 == "")
                        outputBox.Text = "0";
                    else
                    {
                        outputBox.Text = operand2;
                    }

                }
            }

            catch
            {

            }
        }
        private void clearBtn_Click(object sender, EventArgs e)
        { // clear operands and operation and set textbox to "0"
            operand1 = "";
            operand2 = "";
            currentOperation = Operation.NoneSelected;
            outputBox.Text = "0";
        }
        private void clearEntryBtn_Click(object sender, EventArgs e)
        {   // clear operand being entered and set textbox to "0"
            try
            {
                if (currentOperation == Operation.NoneSelected)
                {
                    operand1 = "";
                    outputBox.Text = "0";
                }
                else if (operand2 != "")
                {
                    operand2 = "";
                    outputBox.Text = "0";
                }
            }
            catch { }
        }
        #endregion
        #region Helper Functions
        public void checkLength()
        {
            //check length of output and output to textbox if length is fine
            output = Math.Round(output, 8);
            if (output.ToString().Length > 16)
                outputBox.Text = "Overflow";
            else
                outputBox.Text = output.ToString();
        }
        public void addToHistory(char operation)
        {
            if (outputBox.Text != "Overflow") // if output overflows don't add operation to history
            {
                output = Math.Round(output, 8);
                var newEntry = "";
                if (currentOperation == Operation.NoneSelected)
                {
                    newEntry = "= " + operand1 + "\n\n\n";
                }
                else if (currentOperation == Operation.Square)
                {
                    newEntry = operand1a + "^2 =" + output + "\n\n\n";
                }
                else if (currentOperation == Operation.SquareRoot)
                {
                    newEntry = string.Format("Sqrt({0}) = {1}\n\n\n", operand1a, output);
                }
                else if (currentOperation == Operation.Reciprocal)
                {
                    newEntry = string.Format("1/{0} = {1}\n\n\n", operand1a, output);
                }
                else
                {
                    newEntry = operand1 + operation + operand2 + " = " + output.ToString() + "\n\n\n";
                }
                for (int i = 3; i >= 0; i--)
                {
                    history[i + 1] = history[i];
                }
                history[0] = newEntry;
                historyCount++;
                if (historyCount == 5)
                {
                    historyCount = 0;
                }

                historyBox0.Text = history[4];
                historyBox1.Text = history[3];
                historyBox2.Text = history[2];
                historyBox3.Text = history[1];
                historyBox4.Text = history[0];

            }

        }
        #endregion
        #region equals function
        private void equalBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (currentOperation == Operation.NoneSelected)
                {
                    output = Math.Round(Convert.ToDouble(operand1), 8);
                    outputBox.Text = operand1;
                    addToHistory('_');
                }
                if (operand2 == "")
                {
                    operand2 = operand2a;
                }
                if (currentOperation == Operation.Addition)
                {
                    output = Convert.ToDouble(operand1) + Convert.ToDouble(operand2);
                    checkLength();
                    addToHistory('+');

                }
                else if (currentOperation == Operation.Subtraction)
                {
                    output = Convert.ToDouble(operand1) - Convert.ToDouble(operand2);
                    checkLength();
                    addToHistory('-');
                }
                else if (currentOperation == Operation.Multiplication)
                {
                    output = Convert.ToDouble(operand1) * Convert.ToDouble(operand2);
                    checkLength();
                    addToHistory('*');
                }
                else if (currentOperation == Operation.Division)
                {
                    if (operand2 == "0")
                    {
                        outputBox.Text = "Cannot Divide by Zero";
                        operand1 = "";
                        operand2 = "";
                        currentOperation = Operation.NoneSelected;
                    }
                    else
                    {
                        output = Convert.ToDouble(operand1) / Convert.ToDouble(operand2);
                        checkLength();
                        addToHistory('/');
                    }

                }
                else if (currentOperation == Operation.Power)
                {
                    output = Math.Pow(Convert.ToDouble(operand1), Convert.ToDouble(operand2));
                    checkLength();
                    addToHistory('^');
                }

                if (outputBox.Text != "Cannot Divide by Zero")
                {
                    operand1 = output.ToString();
                    operand2a = operand2;
                    operand2 = "";
                }

            }
            catch
            {
                currentOperation = Operation.NoneSelected;
                operand1 = "";
                operand2 = "";
                outputBox.Text = "Error";
            }

        }
    }
}
        #endregion

